#! /bin/bash

cd ~/RYSX_ws/src/simulation/log
rm -rf *.log