#! /bin/bash

cd ~/github/Firmware
make px4_sitl_default jmavsim