#! /bin/bash

cd ~/RYSX_ws/src/offboard_pkg/log
rm -rf *.log